src = 5;    % 0101 in binary
dst = 10;   % 1010 in binary
pos = 1;    % Copy bit at position 1 (counting from the right)

result = copy_bit(src, dst, pos)