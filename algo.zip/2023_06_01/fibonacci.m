function f = fibonacci(n)
    fibo = [];
    if n==1
        fibo=[0];
    end
    
    if n==2
        fibo=[0 1];
    end
    
    if n>2
        fibo=[0 1];
        for i=3:n
            x=i-2;
            y=i-1;
            j = fibo(i-2)+fibo(i-1);
            fibo=[fibo j];
        end
    end
    
    fibo
    
end