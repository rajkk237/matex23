% Get a number as user input and find all the divisible numbers for that number and print and  
% print those numbers as an array, and after find the multiplication of those divisible numbers

num = input('Enter a number: ');
q = [];
mul = 1;

for i=1:num
    if mod(num,i) == 0
        q = [q i];
        mul = mul*i;
    end
end

disp(['Divisible numbers are : ', num2str(q)]);
disp(['Multibilication = ' ,num2str(mul)]);