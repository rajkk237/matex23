function dst = copy_bit(src, dst, pos)
    src_bin = dec2bin(src);
    dst_bin = dec2bin(dst);
    
    % Get  the bit at the specified position in src
    src_bit = src_bin(end - pos +1);
    dst_bin(end - pos +1) = src_bit;
    dst = bin2dec(dst_bin); % Convert binary string back to the decimal
end