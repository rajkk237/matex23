s = [3 9 5 7 6 8 12 11 10 9 3 5 2 1 4 4 7 2];
t = [9 5 7 6 8 12 11 10 3 10 1 2 1 4 11 12 8 6];
w = [3 1 10 1 2 1 10 1 1 1 1 1 1 1 1 1 1 1];
g = graph(s,t,w);
p = plot(g,'edgelabel',g.Edges.Weight);

path = shortestpath(g,1,3)

highlight(p,path,'EdgeColor','red','LineWidth',3)
