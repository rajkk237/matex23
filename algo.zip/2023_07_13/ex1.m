s=[9 8 8 7 7 6 10 10 9 6 5 1 2 3 4 11 11 11 11 11 11 11 11 11 11];
t=[4 4 3 3 2 2 1 5 5 1 1 2 3 4 5 9 4 8 3 7 2 6 1 10 5];
g= graph(s,t);
p=plot(g,'LineWidth', 5);

% highlight(p,s,t,property,value)

highlight(p,[9 8 8 7 7 6 10 10 9 6] , [4 4 3 3 2 2 1 5 5 1 ], 'EdgeColor','r');
highlight(p,[1 2 3 4 5] , [2 3 4 5 1], 'EdgeColor','g');
highlight(p,[11 11 11 11 11 11 11 11 11 11] , [9 4 8 3 7 2 6 1 10 5], 'EdgeColor','black');
