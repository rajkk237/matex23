s=[5 9 10 13 11 4 8 6 7 9 10 13 1 11 13 4 1 9 9 13 4 2 2 2 2 2 1];
t=[9 10 13 11 4 8 6 7 5 3 3 3 3 12 12 12 12 1 2 1 1 1 8 6 7 5 8];
w=[1 1 2 5 1 4 1 1 1 1 1 3 10 1 1 2 6 5 5 10 10 4 1 2 1 1 1];
g=graph(s,t,w);
p=plot(g,'edgelabel',g.Edges.Weight);
path=shortestpath(g,1,3);
highlight(p,path,'EdgeColor','green','LineWidth',5);
highlight(p,1,3,'EdgeColor','r','LineWidth',5)