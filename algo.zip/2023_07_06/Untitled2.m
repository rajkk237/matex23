%directed grapgh

% s=1;
% t=2:6;
% g=digraph(s,t);
% p=plot(g,'layout','force');
%=======================================================
% s=[4 4 1 1 1 3 3 2];
% t=[5 3 4 3 2 2 5 5];
% g=digraph(s,t);
% p=plot(g,'layout','force');

% ========================================================
% weighted graph
% t=1;
% s=2:6;
% w=[1 3 5 7 9];
% g=graph(s,t,w);
% p=plot(g,'EdgeLabel',g.Edges.Weight,'layout','force');
% ===========================================================
s=[                 ];
t=[             ];
g=digraph(s,t);
p=plot(g,'layout','force');