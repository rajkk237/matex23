function isDisarium(n)
  num_digits = floor(log10(n)) + 1;
  sum = 0;
  for i = num_digits:-1:1
    digit = n % 10;
    sum = sum + digit^(num_digits - i);
    n = n / 10;
  end
  return (sum == n);
end




x=input('Enter number: '); 
disp(x)
temp=x; 
y = 0;
h=fprintf('%d',x); %% it return number of digits
   while x > 0
     t = mod(x,10);
     y = y+t^h;
     x = (x-t)/10;
   end
if(y==temp)
    disp('Amstrong'); 
else
    disp('not amstrong'); 
end