num = input('Enter the number:');

for i=1 : num
    for j=1 : i
        fprintf('%d ',i*j);
    end
    fprintf('\n');
end