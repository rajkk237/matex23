s = [1  1  1  1  1 1  1  2 2 2 2 2 3 3  3  4  4  4  5 5  6 6 9  10  11  11  12];
t = [3 13  12 4  8 2  9  8 6 7 5 9 9 10 13 12 11 8  7 9  7 8 10 13  12  13  13];
w = [10 5  10 10 1 10 6  4 1 2 1 5 1 1 3 2 1  4  1 1  1 1 1  2   1   5   1];
g = graph(s,t,w);
p = plot(g,'edgelabel',g.Edges.Weight);
%path = shortestpath(g,1,3)
source = input('Enter source:');
dest = input('Enter destination:');
[path,length] = shortestpath(g,source,dest);
fprintf('shortest path from %d to %d  is ',source,dest);

for i=source:length
    a=path(1,i);
    fprintf('%d-->',a);
end
fprintf('%d \n',dest);
 fprintf('shortest distance from %d to %d is %d \n',source,dest,length);

highlight(p,path,'EdgeColor','green','LineWidth',3);
highlight(p,1,3,'EdgeColor','r','LineWidth',3);

%Enter source: 1
%Enter destination: 3
%Shortest path from 1 to 3
%the shortest between 1 and 3 is 6

% output=>
% Enter source:1
% Enter destination:3
% shortest path from 1 to 3  is 1-->8-->6-->2-->5-->9-->3 
% shortest distance from 1 to 3 is 6 


%METHOD-2

% fprintf('shortest distance from %d to %d is %d \n',source,dest);
%fprintf('%d --> ', path);







% path =
% 
%      1     8     6     2     5     9     3