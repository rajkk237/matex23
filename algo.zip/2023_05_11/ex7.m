%find factorial vailue using while loop
num = input('Enter your number: ');
cnum = num;
fact=1;
while(1<num)
    fact=fact*num;
    num =  num-1;
end

%fprintf('factorial of %d is %d \n',cnum, fact);
disp(['n! = ' num2str(fact)]); %num2str --> build in function