n =input('Enter your number: ');
sum=0;
for i=1:2:n
    sum=sum+i;
end
fprintf(" odd number sumation upto %d is: %d \n",n,sum);

sum=0;
for i=2:2:n
    sum=sum+i;
end
fprintf(" even number sumation upto %d is: %d \n",n,sum);

%--------------------------------------------------------------------------

sumeven=0;
sumodd=0;

for i=1:n
    if rem(i,2)==0
        sumeven=sumeven+i;
    else
        sumodd=sumodd+i;
    end
end

disp(sumodd)
disp(sumeven)