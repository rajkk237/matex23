zeros(3)
zeros(3,2)
eye(4)

A = [1 2 3; 4 5 6; 7 8 9;];
disp(A);

B = [1,2,3;,4,5,6;,7,8,9;];
disp(B);

C = A + B;
C

for i=1:3
    for j=1:3
        C(i,j)=A(i,j)+B(i,j);
    end
end
disp(C);

%Find matrix multiplication using for loop
A = [1 2 3; 4 5 6; 7 8 9;];
for i=1:3
    for j=1:3
        C(i,j)= C(i,j)+(A(i,j)*B(i,j));
    end
end
disp(C);
