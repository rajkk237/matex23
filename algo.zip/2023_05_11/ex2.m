% An electronic shop has annouced the following seasonal discount on the purchase of cerain items.
% 
%     purchase Amout      Discount
%         0-250               0%
%         251-570             5%
%         571-1000            7.5%
%    more than 1000           10%
%   
% write program based on the above criteria to input name, address, amount of purchace.
% Compute and print the net amount to be paid by a customr along with his name and address
% 
%         Discount = (discount rate/100)*amount purchase
%         net amount = amount of purchase - discount

name = input('Enter your name: ','s');
assress = input('Enter your address: ','s');
amount = input('Enter amount of purchase: ');

if(amount > 1000)
    discount = (10/100)*amount;
else
    if(570<amount<=1000)
        discount = (7.5/100)*amount;
    else
        if(250<amount<=570)
            discount = (5/100)*amount;
        else
            discount = 0;
        end
    end
end

netAmount = amount-discount;
format long;
netAmount;
fprintf('Net amount: %d \n',netAmount);

    