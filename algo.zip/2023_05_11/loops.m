for k=1:2:10
    disp(k);
end

for k=1:10
    disp(k);
end

for k=10:-1:1
    disp(k);
end

%--------------------------------------------------------------------------

a=10;
%while loop execution
while(a<20)
    fprintf('value of a: %d \n',a)
    a=a+1;
end