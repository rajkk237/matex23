n = input('Enter a number between 1 to 7 for select the day: ');
switch n
    case 1
        disp('Monday');
    case 2
        disp('Tuesday');
    case 3
        disp('Wednesday');
    case 4
        disp('Thursday');
    case 5
        disp('Friday');
    case 6
        disp('Saturday');
    case 7
        disp('Sunday');
    otherwise
        disp('Invalid number!');
end