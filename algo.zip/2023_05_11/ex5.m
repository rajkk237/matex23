n =input('Enter your number: ');
sum=0;
for i=1:n
    sum=sum+i;
end
fprintf("sumation upto %d is: %d \n",n,sum);