let = input('Enter your text: ','s');
let = let