n =input('Enter a number: ');
length1(n);
function length1(n)
    for a= 1 : n
        for b = a : n
            for c=1 : n
                if((a*a +  b*b) == c*c)
                       fprintf('A = %d B = %d C = %d \n',a,b,c)
                end
            end
        end
    end
end