x = 7+10/3+5^1.2;
x
format long
x
format short
x
format bank
x

y = pi;
format short e
y
format long e
y

x = 0.5
format rat
x
