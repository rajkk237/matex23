%Read 3 number from user and disply the maximum number and minimum number

num1 = input('Enter number1: ');
num2 = input('Enter number2: ');
num3 = input('Enter number3: ');

max = num1;
if max<num2
    max = num2;
end
if max<num3
    max = num3;
end

min = num1;
if min>num2
    min = num2;
end
if min>num3
    min = num3;
end

fprintf('Maximum is %d \n',max);
fprintf('Minimum is %d \n',min);