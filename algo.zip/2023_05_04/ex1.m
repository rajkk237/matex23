num1 = input('Enter Number 1: ');
num2 = input('Enter Number 2: ');

addition = num1 +num2;
substraction = num1 - num2;
multiplication = num1 * num2;
division = num1 / num2;

% disp('Addition is: ');
% disp(addition);
% disp('Substraction is: ');
% disp(substraction);
% disp('Multipilication is: ');
% disp(multiplication);
% disp('Division is: ');
% disp(division);

fprintf('Addition is = %d \n', addition);
fprintf('Substraction is = %d \n', substraction);
fprintf('Multipilication is = %d \n', multiplication);
fprintf('Division is = %d \n', division);