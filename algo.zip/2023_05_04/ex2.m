name = input('Enter your name: ','s');
age = input('Enter the age: ');
fprintf('My name is %s. I am %d years old. \n',name,age);