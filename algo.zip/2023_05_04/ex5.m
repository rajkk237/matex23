x = 5;
y = 10;
if x>y
    disp(x);
else
    disp(y);
end