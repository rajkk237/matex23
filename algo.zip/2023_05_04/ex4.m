int = 23;
flot = 23.33;
char1 = 'a'
string1 = 'abc'

who
whos