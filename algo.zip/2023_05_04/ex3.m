% 2. Convert temperature in degrees Fahrenheit (.F) to degree Centigrade (.C). 
% Use input and fprintf commands to display a max of number

% Recall the conversion formulation,
% C=5/9 * (F-32)

f = input('Enter temperature in Fahrenheit: ');
c = 5/9 * (f-32);

fprintf('Tempurature in Centigrade = %f \n',c);