function merged_array = mergeSort(array)
  if length(array) <= 1
    return array;
  end

  mid = length(array) / 2;
  left = mergeSort(array(1:mid));
  right = mergeSort(array(mid+1:end));

  merged_array = merge(left, right);

  return merged_array;
end

function merged_array = merge(left, right)
  merged_array = [];
  i = 1;
  j = 1;

  while i <= length(left) && j <= length(right)
    if left(i) <= right(j)
      merged_array = [merged_array left(i)];
      i = i + 1;
    else
      merged_array = [merged_array right(j)];
      j = j + 1;
    end
  end

  merged_array = [merged_array left(i:end)] + [merged_array right(j:end)];

  return merged_array;
end