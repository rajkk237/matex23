bubbleSort.m

function sortedArray = bubbleSort(inputArray)
    n = length(inputArray);
    sortedArray = inputArray;
    
    for i = 1:n-1
        for j = 1:n-i
            if sortedArray(j) > sortedArray(j+1)
                temp = sortedArray(j);
                sortedArray(j) = sortedArray(j+1);
                sortedArray(j+1) = temp;
            end
        end
    end
end

_______________________________________________________________________

inputArray = [4, 2, 7, 1, 3];
sortedArray = bubbleSort(inputArray);
disp(['Sorted Array: ', num2str(sortedArray)]);




+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



selectionSort


function sortedArray = selectionSort(inputArray)
    n = length(inputArray);
    sortedArray = inputArray;
    
    for i = 1:n-1
        minIndex = i;
        for j = i+1:n
            if sortedArray(j) < sortedArray(minIndex)
                minIndex = j;
            end
        end
        if minIndex ~= i
            temp = sortedArray(i);
            sortedArray(i) = sortedArray(minIndex);
            sortedArray(minIndex) = temp;
        end
    end
end

_______________________________________________________________________

inputArray = [4, 2, 7, 1, 3];
sortedArray = selectionSort(inputArray);
disp(['Sorted Array: ', num2str(sortedArray)]);




+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


mergeSort.m


function sortedArray = mergeSort(inputArray)
    n = length(inputArray);
    
    if n <= 1
        sortedArray = inputArray;
        return;
    end
    
    mid = floor(n / 2);
    left = inputArray(1:mid);
    right = inputArray(mid+1:end);
    
    leftSorted = mergeSort(left);
    rightSorted = mergeSort(right);
    
    sortedArray = merge(leftSorted, rightSorted);
end

function mergedArray = merge(left, right)
    i = 1;
    j = 1;
    mergedArray = [];
    
    while i <= length(left) && j <= length(right)
        if left(i) <= right(j)
            mergedArray = [mergedArray, left(i)];
            i = i + 1;
        else
            mergedArray = [mergedArray, right(j)];
            j = j + 1;
        end
    end
    
    while i <= length(left)
        mergedArray = [mergedArray, left(i)];
        i = i + 1;
    end
    
    while j <= length(right)
        mergedArray = [mergedArray, right(j)];
        j = j + 1;
    end
end


_______________________________________________________________________

inputArray = [4, 2, 7, 1, 3];
sortedArray = mergeSort(inputArray);
disp(['Sorted Array: ', num2str(sortedArray)]);



+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


function sortedArray = quickSort(inputArray)
    if length(inputArray) <= 1
        sortedArray = inputArray;
        return;
    end
    
    pivot = inputArray(end);
    left = [];
    right = [];
    
    for i = 1:length(inputArray)-1
        if inputArray(i) <= pivot
            left = [left, inputArray(i)];
        else
            right = [right, inputArray(i)];
        end
    end
    
    sortedLeft = quickSort(left);
    sortedRight = quickSort(right);
    
    sortedArray = [sortedLeft, pivot, sortedRight];
end


_______________________________________________________________________

inputArray = [4, 2, 7, 1, 3];
sortedArray = quickSort(inputArray);
disp(['Sorted Array: ', num2str(sortedArray)]);


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

function sortedArray = insertionSort(inputArray)
    n = length(inputArray);
    sortedArray = inputArray;
    
    for i = 2:n
        key = sortedArray(i);
        j = i - 1;
        
        while j > 0 && sortedArray(j) > key
            sortedArray(j + 1) = sortedArray(j);
            j = j - 1;
        end
        
        sortedArray(j + 1) = key;
    end
end

_______________________________________________________________________

inputArray = [4, 2, 7, 1, 3];
sortedArray = insertionSort(inputArray);
disp(['Sorted Array: ', num2str(sortedArray)]);
