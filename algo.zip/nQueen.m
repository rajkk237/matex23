IT 2223 Design and Analysis of algorithms
Level II
Stream
Classwork
People
IT 2223 Design and Analysis of algorithms Level II
IT 2223 Design and Analysis of algorithms
Level II
Upcoming
Woohoo, no work due soon!

Announce something to your class

Announcement: "Up to now basic matlab codes"
Anjalee Irudinee
Created Oct 16, 2022Oct 16, 2022
Up to now basic matlab codes

IT2223New Syllubus.rar
Compressed Archive

nqueenFinal.m
Objective C

Add class comment…


Announcement: "ICA02 and 03"
Anjalee Irudinee
Created Oct 16, 2022Oct 16, 2022
ICA02 and 03

Ica3Finalpdf.pdf
PDF

IT2223(P)_ICA02.pdf
PDF

Add class comment…


Announcement: "ICA01 Question Paper"
Anjalee Irudinee
Created Sep 22, 2022Sep 22, 2022
ICA01 Question Paper

ICA 01 (P).pdf
PDF

Add class comment…


Announcement: "String Functions"
Anjalee Irudinee
Created Sep 12, 2022Sep 12, 2022
String Functions

stringfunc.m
Objective C

Add class comment…


Announcement: "Matlab Introduction part3(2022.08.24)"
Anjalee Irudinee
Created Aug 24, 2022Aug 24, 2022
Matlab Introduction part3(2022.08.24)

Matlab part3.pptx
PowerPoint

Add class comment…


Announcement: "Day 3(2022.08.01) zoom recording"
Anjalee Irudinee
Created Aug 2, 2022Aug 2, 2022
Day 3(2022.08.01) zoom recording

Day 3 record.mp4
Video

Add class comment…

Assignment: "IT 2223 Practical Book Submission (No.2)"
Anjalee Irudinee posted a new assignment: IT 2223 Practical Book Submission (No.2)
Created Aug 1, 2022Aug 1, 2022

Announcement: "Day 03(2022.08.01)"
Anjalee Irudinee
Created Aug 1, 2022Aug 1, 2022
Day 03(2022.08.01)

MATLAB Introduction.pptx
PowerPoint

Add class comment…


Announcement: "Day 02(2022.07.27)"
Anjalee Irudinee
Created Jul 28, 2022Jul 28, 2022
Day 02(2022.07.27)

Recursion.pptx
PowerPoint

MATLB.pptx
PowerPoint

Add class comment…


Announcement: "Day 01 Intrduction"
Anjalee Irudinee
Created Jul 28, 2022Jul 28, 2022
Day 01
Intrduction

Design and Analysis of Algorithm.pptx
PowerPoint

Add class comment…

Assignment: "IT 2223 Practical No1"
Anjalee Irudinee posted a new assignment: IT 2223 Practical No1
Created Jul 28, 2022Jul 28, 2022
global N;
N = input("Enter the number of queens: ")


% chessboard
% NxN matrix with all elements 0
global board ;
board= zeros(N);
b=N_queen(N);
board

%for image
a=zeros(N)+0.6;
for i=1:N
    for j=1:N
    if rem(i+j,2)==0
    a(i,j)=0.9;
    end
    end
end
h=imshow(a,'InitialMagnification',5000);
axis equal
axis on
for i=1:N
    for j=1:N
    if board(i,j)==1;
    queen(i,j)=text(i,j,char(9819),...
        'HorizontalAlignment','center',...
        'FontSize',30);
    end
    end
end

%image end code

function y=N_queen(n)
    global board;
    global N;

if n==0
        y=1;
        return
    end
    for i =1:N
        for j=1:N
            
% %             checking if we can place a queen here or not
%             queen will not be placed if the place is being attacked
%             or already occupied
            if (is_attack(i,j)==0) && (board(i,j)~=1)
                board(i,j) = 1;
            
%                 #recursion
%                 #wether we can put the next queen with this arrangment or not

                if N_queen(n-1)==1
                    y= 1;
                    return
                    
                end
                board(i,j) = 0;
                
            end
        end
    end
    y=0;
    
end

function x= is_attack(i, j)
    global N
    global board;
%     checking if there is a queen in row or column
   
    for k =1:N
        if board(i,k)==1 | board(k,j)==1
            x= 1;
            return
        end
    end
%     checking diagonals
    for k =1:N
        for l =1:N
            if (k+l==i+j) | (k-l==i-j)
                if board(k,l)==1
                    x=1;
                    return
                end
            end
        end
    end
    x=0;
    
end


nqueenFinal.m
Displaying nqueenFinal.m.