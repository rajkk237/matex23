weights = [3 2 4 1];
values = [5 3 7 2];
W=5;

% Calling the function knapsack_01
[maxValue, selectedItems] = knapsack_01(weights, values, W);
disp("Maximum profit: " + maxValue);
disp("Selected Item: " + mat2str(selectedItems));

function [maxValue, selectedItems] = knapsack_01(weights, values, W)
    n = length(weights);
    dp = zeros(n+1, W+1);
    for i = 1:n
        for j = 1:W
            if weights(i) > j
                dp(i+1, j+1) = dp(i, j+1);
            else
                dp(i+1, j+1) = max(dp(i, j+1), dp(i, j-weights(i)+1) + values(i));
            end
        end
    end
    
    % Backracking to find selected items
    selectedItems = [];
    i = n;
    j = W;
    while i > 0 && j > 0
        if dp(i+1, j+1) ~= dp(i, j+1)
            selectedItems = [i, selectedItems];
            j = j - weights(i);
        end
        i = i - 1;
    end
    maxValue = dp(n+1, W+1);
end




---------------------------------------------------------------------------------------------------------------------


function max_value = knapsack(weights, values, W)
    n = length(weights);
    dp = zeros(n+1, W+1);
    
    for i = 1:n
        for w = 1:W
            if weights(i) <= w
                dp(i+1, w+1) = max(dp(i, w+1), values(i) + dp(i, w+1-weights(i)));
            else
                dp(i+1, w+1) = dp(i, w+1);
            end
        end
    end
    
    max_value = dp(n+1, W+1);
end

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

weights = [2, 3, 4, 5];
values = [3, 4, 5, 6];
W = 5;
max_value = knapsack(weights, values, W);
disp(['Maximum Value: ', num2str(max_value)]);