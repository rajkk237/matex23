function isDisarium(n)
  num_digits = floor(log10(n)) + 1;
  sum = 0;
  for i = num_digits:-1:1
    digit = n % 10;
    sum = sum + digit^(num_digits - i);
    n = n / 10;
  end
  return (sum == n);
end