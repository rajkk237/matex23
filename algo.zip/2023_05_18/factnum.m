function f = factnum(n)
    f = prod(1:n);
end