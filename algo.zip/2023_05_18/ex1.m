%raw and cloumn vector represent
list1=input('Type in a vector of integers: ');
disp(list1);

% ----------output-----------
% ex1
% Type in a vector of integers: 1
%      1
% 
% ex1
% Type in a vector of integers: [1 2 3 4 5]
%      1     2     3     4     5
%      
% ex1
% Type in a vector of integers: [1,2,3,4,5]
%      1     2     3     4     5
% 
% ex1
% Type in a vector of integers: [1;2;3;4;5]
%      1
%      2
%      3
%      4
%      5

list2=sort(list1);
disp(list2);

% ----------output-----------
% ex1
% Type in a vector of integers: [15 34 3 23 123]
%     15    34     3    23   123
% 
%      3    15    23    34   123

matrix=input('Type in a matrix of integers: ');
disp(matrix);
matrix=sort(matrix);
disp(matrix);

% ----------output-----------
% Type in a matrix of integers: [15 34 3 23 123; 12 21 34  23 4]
%     15    34     3    23   123
%     12    21    34    23     4
% 
%     12    21     3    23     4
%     15    34    34    23   123
