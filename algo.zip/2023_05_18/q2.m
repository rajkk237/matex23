N = 5;
for i=1:N
    fprintf('*\n');
end

% -------------Q3---------------
for i=1:N
    fprintf('*');
end
fprintf('\n');

% -------------Q4---------------
for i=1:N
    for j=1:i
        fprintf('*');
    end
    fprintf('\n');
end

% -------------Q5---------------
for i=1:N
    for j=1:N
        fprintf('* ');
    end
    fprintf('\n');
end

