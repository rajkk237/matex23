function [add,sub,mul,div]=arithmatic_operations(A,B)
add=A+B
sub=A-B
mul=A*B
div=A/B
end

% file name should same as the function name.       arithmatic_operations.m