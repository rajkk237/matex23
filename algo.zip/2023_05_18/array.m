arr1 = [12, 43, 67, 45];
arr2 = [34, 87, 12, 15];

sum = arr1 + arr2;
disp(sum);

sub = arr1 - arr2;
disp(sub);

scal = 5 * arr1;
disp(scal);

col1=[12; 43; 67; 45];
col2=[34; 87; 12; 15];

sum = col1 + col2;
disp(sum);

sub = col1 - col2;
disp(sub);

scal = 5 * col1;
disp(scal);

% ----------output----------
% array
%     46   130    79    60
% 
%    -22   -44    55    30
% 
%     60   215   335   225
% 
%     46
%    130
%     79
%     60
% 
%    -22
%    -44
%     55
%     30
% 
%     60
%    215
%    335
%    225