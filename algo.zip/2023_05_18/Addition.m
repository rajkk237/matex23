function Y = Addition(A,B)
Y=A+B;
end

% file name should same as the function name.