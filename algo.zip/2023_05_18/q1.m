% ax^2 + bx + c = 0
a = input('Enter the value of a: ');
b = input('Enter the value of b: ');
c = input('Enter the value of c: ');

x=(-b +  sqrt(b^2 -4*a*c))/2*a
x=(-b -  sqrt(b^2 -4*a*c))/2*a