A=50;
B=20;
C=Addition(A,B);

D=arithmatic_operations(A,B);