% writr a pogram to find a user given number is a palindrome or not
% You have to convert that decimal number into binary format and find 
% that binary number is a palindrome or not

a = 15;
b = dec2bin(a);

%intb = str2num(b)
 
c = reverse(b);
 
if b==c
    fprintf('Palindrome\n');
else
    fprintf('Not a palindrome\n');
end
 
% c = length(b);
out = fliplr(b)
if b==out
    fprintf('It is a palindrom\n');
else
    fprintf('It is not a palindrom\n');
end

% ---------------------------manual way----------------------------
a=input('Enter a number');
num = dec2bin(a);
num1=str2num(num);
temp=num1;
reverse=0;
while num1>0
    t=mod(num1,10);
    reverse=10*reverse+t;
    num1=(num1-t)/10;
end
reverse
temp
if temp==reverse
    disp('Number is palindrome.');
else
    disp('Number is not a palindrome.');
end
