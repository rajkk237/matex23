factorial = prod(1:5)

% prod is predifine function. for factorial.