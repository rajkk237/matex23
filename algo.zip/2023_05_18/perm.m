%permutation value...? 6P4 = 6!/4! = 30

function p = perm(n,r)
    n=6; r=2;
    p = factnum(n)/factnum(n-r);
end
