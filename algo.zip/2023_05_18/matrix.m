a = [1 2 3 4 5];
b = [6 7 8 9 10];

c = [a,b];
d = [a;b];

disp(c)
disp(d)
%% not working beacuse of the file name!!!!!  MATRIX.M